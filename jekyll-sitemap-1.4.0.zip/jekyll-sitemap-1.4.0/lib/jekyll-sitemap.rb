# frozen_string_literal: true

require "jekyll/page_without_a_file"
require "jekyll/jekyll-sitemap"
