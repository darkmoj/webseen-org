# frozen_string_literal: true

module Jekyll
  module Sitemap
    VERSION = "1.4.0"
  end
end
